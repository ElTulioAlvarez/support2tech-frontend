import { ENV } from "../../app/config/env";
import { tokenStorage } from "../storage/tokenStorage";
import { authEvents } from "./authEvents";

type ApiErrorShape = {
  message?: string;
};

type ApiRequestOptions = RequestInit & {
  requireAuth?: boolean;
  autoLogoutOn401?: boolean;
};

async function parseError(res: Response) {
  try {
    const data = (await res.json()) as ApiErrorShape;
    return data?.message || `HTTP ${res.status}`;
  } catch {
    return `HTTP ${res.status}`;
  }
}

export const apiClient = {
  async request<T>(path: string, init?: ApiRequestOptions): Promise<T> {
    const {
      requireAuth = true,
      autoLogoutOn401 = false,
      ...fetchInit
    } = init ?? {};

    const token = tokenStorage.get();

    const headers = new Headers(fetchInit.headers);

    const hasBody =
      fetchInit.body !== undefined &&
      fetchInit.body !== null &&
      !(fetchInit.body instanceof FormData);

    if (hasBody && !headers.has("Content-Type")) {
      headers.set("Content-Type", "application/json");
    }

    if (requireAuth && token) {
      headers.set("Authorization", `Bearer ${token}`);
    }

    const res = await fetch(`${ENV.API_URL}${path}`, {
      ...fetchInit,
      headers,
    });

    if (!res.ok) {
      const msg = await parseError(res);

      if (res.status === 401 && autoLogoutOn401) {
        tokenStorage.clear();
        authEvents.emitUnauthorized();
      }

      throw new Error(msg);
    }

    if (res.status === 204) {
      return undefined as T;
    }

    return (await res.json()) as T;
  },
};