export const ENV = {
  API_URL: import.meta.env.VITE_API_URL as string,
};